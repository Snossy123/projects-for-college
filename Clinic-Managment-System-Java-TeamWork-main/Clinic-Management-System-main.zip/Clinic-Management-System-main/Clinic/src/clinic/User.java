package clinic;

 public interface User 
{
            void changepassword(String username , String user_old_password ,String user_new_password);
            void logout();

}