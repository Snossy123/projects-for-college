
package clinic;

import java.sql.*;
 
public class Clinic {

     public static void main(String[] args) throws SQLException, ClassNotFoundException {
     login_page login = new login_page();
    
    }
    
}
