# Clinic-Management-System
The project clinic management is software developed to simplify the communication
process between the doctor and the receptionist while dealing with patients.
## User of this programe
The software would be operated by three users Admin, Receptionist and Doctor.
### The Link of video description
https://www.youtube.com/watch?v=MJ613orAmTs
###Database how to work it in project ? 
1- https://www.apachefriends.org/download.html
2- https://youtube.com/playlist?list=PLMTdZ61eBnyoQoEmLOcgTBdrAOVT-GFju
3- https://youtu.be/LRWtCFQe69c
4- https://youtu.be/Lq8V-pD4qCo
5- https://youtu.be/lkQSltTG43Q
6- https://youtube.com/watch?v=3tm5C01it-Y&feature=share
watch there videos to learn how to make local host and create datebase and import my database 
Don't forget to put photos in your project
